//
//  AddressBook_Cell.swift
//  AddressBook
//
//  Created by Dhritiman Saha on 27/10/16.
//  Copyright © 2016 Dhritiman Saha. All rights reserved.
//

import UIKit

class AddressBook_Cell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
