//
//  Contacts+CoreDataProperties.swift
//  AddressBook
//
//  Created by Dhritiman Saha on 02/11/16.
//  Copyright © 2016 Dhritiman Saha. All rights reserved.
//

import Foundation
import CoreData


extension Contacts {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Contacts> {
        return NSFetchRequest<Contacts>(entityName: "Contacts");
    }

    @NSManaged public var name: String?
    @NSManaged public var mobile: String?
    @NSManaged public var address: String?

}
