//
//  Contacts+CoreDataClass.swift
//  AddressBook
//
//  Created by Dhritiman Saha on 02/11/16.
//  Copyright © 2016 Dhritiman Saha. All rights reserved.
//

import Foundation
import CoreData


public class Contacts: NSManagedObject {

}
