//
//  AddContactController.swift
//  AddressBook
//
//  Created by Dhritiman Saha on 29/10/16.
//  Copyright © 2016 Dhritiman Saha. All rights reserved.
//

import UIKit
import CoreData

class AddContactController: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var mobileNoTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    var appDelegate : AppDelegate!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate =
            UIApplication.shared.delegate as! AppDelegate
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        super.viewWillAppear(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backBtnAction(_ sender: AnyObject) {
        let _ = self.navigationController?.popViewController(animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func addContactBtnAction(_ sender: AnyObject) {
        if self.nameTextField.text?.characters.count == 0 {
            let alertController = UIAlertController(title: Bundle.main.infoDictionary!["CFBundleName"] as? String, message: "Enter your name", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            self.present(alertController, animated: true, completion: { _ in })
            
        } else if self.mobileNoTextField.text?.characters.count == 0{
            let alertController = UIAlertController(title: Bundle.main.infoDictionary!["CFBundleName"] as? String, message: "Enter your mobile number", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            self.present(alertController, animated: true, completion: { _ in })
        } else if self.addressTextField.text?.characters.count == 0{
            let alertController = UIAlertController(title: Bundle.main.infoDictionary!["CFBundleName"] as? String, message: "Enter your address", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            self.present(alertController, animated: true, completion: { _ in })
        } else{
            let managedContext = appDelegate.managedObjectContext
            
            //2
            let entity =  NSEntityDescription.entity(forEntityName: "Contacts", in: managedContext)
            
            let person = NSManagedObject(entity: entity!,
                                         insertInto: managedContext)
            
            //3
            person.setValue(self.nameTextField.text, forKey: "name")
            person.setValue(self.mobileNoTextField.text, forKey: "mobile")
            person.setValue(self.addressTextField.text, forKey: "address")
            
            //4
            do {
                try managedContext.save()
                print (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
                //5
//                people.append(person)
                let alertCon = UIAlertController (title : Bundle.main.infoDictionary!["CFBundleName"] as? String, message:"Successfully added!!!", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default){ (action:UIAlertAction!) in
                    let _ = self.navigationController?.popViewController(animated: true)
                }
                alertCon.addAction(ok)
                self.present(alertCon, animated: true, completion: nil)
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }

}
