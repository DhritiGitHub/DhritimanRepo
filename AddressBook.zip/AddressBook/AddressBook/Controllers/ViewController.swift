//
//  ViewController.swift
//  AddressBook
//
//  Created by Dhritiman Saha on 27/10/16.
//  Copyright © 2016 Dhritiman Saha. All rights reserved.
//

import UIKit
import CoreData

enum MyError: Error {
    case FoundEmpty(err : String)
}
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var appDelegate : AppDelegate!
    @IBOutlet weak var addressTblVw : UITableView!
    var addressBookArr : NSMutableArray!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        addressBookArr = NSMutableArray()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.getContactList()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //pragma mark- UITableView DataSources
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addressBookArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:AddressBook_Cell = tableView.dequeueReusableCell(withIdentifier: "AddressBook_Cell", for: indexPath) as! AddressBook_Cell
        let address = addressBookArr.object(at: indexPath.row) as? Contacts
        
        cell.nameLabel.text = address?.name
        cell.mobileLabel.text = address?.mobile
        cell.addressLabel.text = address?.address
        
        return cell
    }
    //pragma mark- UITableView Delegates
    @IBAction func addContactBtnAction(_ sender: AnyObject) {
        performSegue(withIdentifier: "ListToAddContactSegue", sender: nil)
    }
    func getContactList() -> Void {
        
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Contacts")
        
        // Create Entity Description
        let entityDescription = NSEntityDescription.entity(forEntityName: "Contacts", in: managedContext)
        
        // Configure Fetch Request
        fetchRequest.entity = entityDescription
        
        do {
            let results = try? managedContext.fetch(fetchRequest)
            let addressArr : NSMutableArray = NSMutableArray.init(array: results!)
            guard addressArr.count > 0 else
            {
                throw MyError.FoundEmpty(err:"The addressbook is empty")
            }
            addressBookArr.removeAllObjects()
            for obj in addressArr
            {
                let add : Contacts = obj as! Contacts
                
                addressBookArr.add(add)
            }
            if addressBookArr.count > 0 {
                self.addressTblVw.reloadData()
            }
            print(results)
        } catch MyError.FoundEmpty(let errorGet) {
            print(errorGet)
        } catch {
            print("Something went wrong!")
        }
        
    }
}

